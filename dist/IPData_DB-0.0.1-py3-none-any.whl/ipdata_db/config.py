# mongo_url = ""
# mongo_port = ""
# mongo_user = ""
# mongo_passwd = ""
# ipdata_api_key = ""

# def setup(mongourl, mongoport, mongouser, mongopasswd, ipdata_apikey):
# 	mongo_url = mongourl
# 	mongo_port = mongoport
# 	mongo_user = mongouser
# 	mongo_passwd = mongopasswd
# 	ipdata_api_key = ipdata_apikey

# def list():
# 	print("url = '" + str(mongo_url) + "'")
# 	print("port = '" + str(mongo_port) + "'")
# 	print("user = '" + str(mongo_user) + "'")
# 	print("passwd = '" + str(mongo_passwd) + "'")
# 	print("api_key = '" + str(ipdata_api_key) + "'")